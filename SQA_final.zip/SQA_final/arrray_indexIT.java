/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author aks82
 */
public class arrray_indexIT {
    
    public arrray_indexIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of find_array method, of class arrray_index.
     */
    @Test
    public void testFind_array() {
        System.out.println("find_array");
        int[] a1 = {10,20,30,55};
        int no1 = 55;
        arrray_index instance = new arrray_index();
        String expResult = "your element is this index 3";
        String result = instance.find_array(a1, no1);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }
    
}
