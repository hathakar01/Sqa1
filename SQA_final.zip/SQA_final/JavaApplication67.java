/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manenathiaavdtu;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author aks82
 */
public class JavaApplication67 {

    /**
     * @param args the command line arguments
     * @throws java.lang.InterruptedException
     */
    public static void main(String[] args) throws InterruptedException {
        ChromeDriver cd = new ChromeDriver();
        cd.get("http://127.0.0.1:5500/arthmetic%20(1).html");
        cd.manage().window().maximize();
        cd.findElement(By.name("first")).sendKeys("25");
        cd.findElement(By.name("second")).sendKeys("12");
        Thread.sleep(3000);
        cd.findElement(By.name("ADD")).click();
        Thread.sleep(3000);
        cd.switchTo().alert().accept();
        Thread.sleep(3000);
        cd.findElement(By.name("SUB")).click();
        Thread.sleep(3000);
        cd.switchTo().alert().accept();
        Thread.sleep(3000);
        cd.findElement(By.name("DIV")).click();
        Thread.sleep(3000);
        cd.switchTo().alert().accept();
        Thread.sleep(3000);
        cd.findElement(By.name("MUL")).click();
        Thread.sleep(3000);
        cd.switchTo().alert().accept();
        Thread.sleep(3000);
        cd.findElement(By.name("first")).clear();
        cd.findElement(By.name("second")).clear();
        Thread.sleep(3000);
        cd.findElement(By.name("MUL")).click();
        Thread.sleep(3000);
        cd.switchTo().alert().accept();
        Thread.sleep(3000);
        cd.findElement(By.name("first")).sendKeys("10");
        cd.findElement(By.name("second")).sendKeys("-25");
        Thread.sleep(3000);
        cd.findElement(By.name("MUL")).click();
        Thread.sleep(3000);

//          WebElement p = cd.findElement(By.name("total"));
//          String st  = p.getAttribute("value");
//          System.out.println(st);
//        cd.close();
        cd.close();
        // TODO code application logic here
    }

}
