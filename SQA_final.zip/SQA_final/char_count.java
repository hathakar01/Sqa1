/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author aks82
 */
public class char_count {
    int c_count(int s1)
    {
        int fact=1;
        if(s1==0)
        {
            return 0;
        }
        for(int i=1;i<=s1;i++)
        {
            fact *=i;
        }
        return fact;
        
    }
    
}
