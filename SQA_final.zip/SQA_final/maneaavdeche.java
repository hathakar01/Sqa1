/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manenathiaavdtu;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author aks82
 */
public class maneaavdeche {
    
        public static void main(String[] args) throws InterruptedException {
        ChromeDriver driver = new ChromeDriver();
        driver.get("https://google.com");
        driver.manage().window().maximize();
        
        driver.findElement(By.name("q")).click();
        driver.findElement(By.name("q")).sendKeys("Great Day");
        Thread.sleep(5000);
        
        driver.findElement(By.name("btnK")).click();
        Thread.sleep(4000);
        List<WebElement> links = (List<WebElement>) driver.findElements(By.tagName("a"));
        System.out.println("Total Related Results are: "+links.size());
        Thread.sleep(4000);
    }
         
         
    }
    

