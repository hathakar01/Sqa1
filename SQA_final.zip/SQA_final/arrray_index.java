/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author aks82
 */
public class arrray_index {
    String find_array(int a1[],int no1)
    {
        if(a1==null)
        {
            return "Your Array is null";
        }
        else if(a1.length==0)
        {
            return "Your Array is empty";
        }
        for(int i=0;i<a1.length;i++)
        {
            if(a1[i]==no1)
            {
                return "your element is this index "+i;
            }
        }
        return "number not found";
    }
    
}
