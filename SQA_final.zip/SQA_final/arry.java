/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author aks82
 */
public class arry {
    public int avg (int a1[]){
        int sum=0;
        int min=10;
        int max=50;
        int counter=0;
        int avg;
        for(int i=0;i<a1.length;i++)
        {
            if(a1[i]>=10 && a1[i]<=50)
            {
               counter++;
               sum=sum+a1[i];
            }
        }
        avg=sum/counter;
        return avg;
    }
    
}
