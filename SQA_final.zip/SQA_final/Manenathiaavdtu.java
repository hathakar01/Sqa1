/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manenathiaavdtu;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author aks82
 */
public class Manenathiaavdtu {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        ChromeDriver cd= new ChromeDriver();
        cd.get("https://charusat.edu.in:912/eGovernance/");
        cd.manage().window().maximize();
        Thread.sleep(3000);
        cd.findElement(By.name("txtUserName")).click();
        cd.findElement(By.name("txtUserName")).sendKeys("22MCA086");
        cd.findElement(By.name("txtPassword")).click();
        cd.findElement(By.name("txtPassword")).sendKeys("170100");
        
         Thread.sleep(3000);
         cd.findElement(By.id("btnLogin")).click();
          Thread.sleep(3000);
          JavascriptExecutor js = (JavascriptExecutor) cd;
          js.executeScript("window.scrollBy(0,700)");
          cd.findElement(By.className("fa-bars")).click();
          cd.findElement(By.id("LinkProfile")).click();
          cd.findElement(By.className("fa-power-off")).click();
          Thread.sleep(3000);
          //cd.close();
    }
    
}
