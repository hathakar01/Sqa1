/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seleniumpractice;

import com.beust.jcommander.internal.Console;
import com.sun.java.swing.plaf.windows.resources.windows;
import java.sql.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.edge.EdgeDriver;

/**
 *
 * @author dhrus
 */
public class SeleniumPractice {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        EdgeDriver ed = new EdgeDriver();
        
        ed.get("https://www.google.com/");
        ed.manage().window().maximize();
        ed.findElement(By.className("gLFyf")).sendKeys("Famous Error Code at servers");
        ed.findElement(By.className("gNO89b")).submit();
        String data = ed.findElement(By.className("LGOjhe")).getText();
        System.out.println(data);
        ed.executeScript("console.log(window.data)");
//        ed.findElement(By.tagName("qOiK6e")).click();
//        String url = ed.getCurrentUrl();
//        System.out.println(url);
//        ed.findElement(By.className("CqeZic")).click();
//        Thread.sleep(3000);
//        
//        ed.get("https://www.youtube.com/");
//        ed.manage().window().maximize();
//        Thread.sleep(5000);
//        ed.findElement(By.name("search_query")).click();
//        ed.findElement(By.name("search_query")).sendKeys("Shark Tank India");
//        ed.findElement(By.id("search-icon-legacy")).click();
////        JavascriptExecutor js = (JavascriptExecutor) ed;
////        js.executeScript("windows.scrollBy(0,1000)");
////      Thread.sleep(5000);
//        String url = ed.getCurrentUrl();
//        System.out.println(url);
//        String title = ed.getTitle();
//        System.out.println(title);
//        if(title == "YouTube"){
//            System.out.println("You Are using youTube");
//        }
// TODO code application logic here
    }
    
}
