
package stdregform;

import com.sun.java.swing.plaf.windows.resources.windows;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author valan
 */
public class StdRegForm {

    
    public static void main(String[] args) throws InterruptedException {
        // TODO code application logic here
        ChromeDriver cd = new ChromeDriver();
        cd.get("http://localhost/StudentRegForm/RegForm.html");
        cd.manage().window().maximize();
        Thread.sleep(1000);
        cd.findElement(By.name("firstName")).sendKeys("Vivek");
        Thread.sleep(1000);
        cd.findElement(By.name("lastName")).sendKeys("Parekh");
        Thread.sleep(1000);
        cd.findElement(By.id("male")).click();
        Thread.sleep(100);
        cd.findElement(By.name("email")).sendKeys("VivekParekhgmail.com");
        Thread.sleep(1000);
        cd.findElement(By.name("address")).sendKeys("Nadiad");
        Thread.sleep(1000);
        cd.findElement(By.name("submit")).click();
        String msg = cd.findElement(By.name("email")).getAttribute("validationMessage");
        System.out.println("Error message : "+msg);
        cd.close();
    }
    
}
